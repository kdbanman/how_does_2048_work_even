# how does 2048 work even?

I had a spare few hours and wanted to know how [2048](https://gabrielecirulli.github.io/2048/) worked, so I built it.  (Badly.)

I built it in [Processing](https://processing.org/) because it's easy-peasy to do small things quickly.

It looks like this:

![starting state](assets/start_state.png)

![played state](assets/played_state.png)

And futzing with some magic numbers in the code can make it playable on a much bigger grid:

![big grid](assets/bigger.gif)
