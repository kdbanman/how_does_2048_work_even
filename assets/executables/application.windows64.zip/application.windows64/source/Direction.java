
enum Direction {
  LEFT, UP, DOWN, RIGHT, NONE
};

